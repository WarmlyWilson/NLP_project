# moses-scripts

A number of preprocessing scripts extracted from Moses (https://github.com/moses-smt/mosesdecoder)
